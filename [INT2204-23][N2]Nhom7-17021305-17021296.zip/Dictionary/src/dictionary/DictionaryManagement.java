
package dictionary;

import java.util.Scanner;
import java.io.*;
import java.util.Collections;

public class DictionaryManagement {
	/////////////////////////////////////////////////////////
	//nhap word tu file
	public static void insertFromFile () {
            Dictionary.lib.removeAll(Dictionary.lib);
            //System.out.println(Dictionary.lib.isEmpty());
            try{
                Scanner sc=new Scanner(new FileInputStream("dictionaries.txt"));
                while (sc.hasNext()) {
                    String line=sc.nextLine();
                    String[] split=line.split("\t");
                    String eng=split[0].trim();
                    String vie=split[1].trim();
                    Dictionary.newWord(eng,vie);
                    //System.out.println(eng);
                }
            } catch(IOException e) {
                e.printStackTrace();
            }
//            for(Word a:Dictionary.lib) {
//                System.out.println(a.word_target);
//            }
            //System.out.println(Dictionary.lib.get(0).word_target.length());
            //System.out.println(Dictionary.lib.get(0).word_target.substring(0,3));
            Collections.sort(Dictionary.lib, new sortDict());
	}
	

	
	/////////////////////////////////////////////////////////
	//xoa tu
	public static boolean deleteWord(String eng) {
            boolean noWord=true;

            for (Word a:Dictionary.lib) {	//tim tu can xoa trong tu dien
                if (a.word_target.toLowerCase().contentEquals(eng)) {
                    Dictionary.lib.remove(a);
                    noWord=false;
                    break;
                }
            }
            return noWord;
	}
	
	/////////////////////////////////////////////////////////
	//update tu
//	public static void updateWord() {
//            System.out.print("type the word you want to update: ");
//            Scanner sc=new Scanner(System.in);
//            String eng=sc.nextLine();
//            boolean noWord=true;
//
//            for (Word a:Dictionary.lib) {	//tim tu can update trong tu dien
//                if (a.word_target.contentEquals(eng)) {
//                    System.out.print("update english word: ");
//                    a.word_target=sc.nextLine();
//                    System.out.print("update meaning: ");
//                    a.word_explain=sc.nextLine();
//                    noWord=false;
//                    break;
//                }
//            }
//
//            if (noWord) {
//                System.out.println(eng+" does not exist in this dictionary");
//            }
//            else {
//                System.out.println("Finished updating!");
//                Collections.sort(Dictionary.lib, new sortDict());
//            }
//		
//	}
	
	/////////////////////////////////////////////////////////
	//xuat tu dien ra file
	public static void dictionaryExportToFile()	{
            try{ 
                PrintWriter out = new PrintWriter(new FileWriter("dictionaries.txt"));
                for (Word a:Dictionary.lib) {
                    out.println(a.word_target +"	"+a.word_explain);
                }
                out.close();
            } catch(IOException e) {
                e.printStackTrace();
            }
	}
}